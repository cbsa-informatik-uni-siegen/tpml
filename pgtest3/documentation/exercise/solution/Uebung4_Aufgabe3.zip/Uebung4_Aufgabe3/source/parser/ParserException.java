package parser;

/**
 * Ausnahme bei Lexer/Parser-Fehlern.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class ParserException extends RuntimeException {
	/**
	 * Konstruktor fuer <tt>ParserException</tt>s mit der Fehlermeldung <tt>message</tt>.
	 * 
	 * @param message die Lexer/Parser-Fehlermeldung.
	 */
	ParserException(String message) {
		super(message);
	}
}
