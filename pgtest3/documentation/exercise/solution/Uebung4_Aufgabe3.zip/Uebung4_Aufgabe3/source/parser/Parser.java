package parser;

import java.io.Reader;

import java_cup.runtime.Symbol;

import expressions.Expression;

/**
 * Die Parser-Schnittstelle zum Uebersetzen der konkreten Syntax in die abstrakte Syntax.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Parser extends AbstractParser {
	/**
	 * Konstruktor fuer einen neuen <tt>Parser</tt>, der die Eingabe von dem <tt>reader</tt> liesst.
	 * 
	 * @param reader der <tt>Reader</tt> fuer den Eingabezeichenstrom.
	 */
	public Parser(Reader reader) {
		super(new Lexer(reader));
	}
	
	/**
	 * Liefert den geparsten Ausdruck.
	 * 
	 * @return den Ausdruck in der abstrakten Syntax.
	 * 
	 * @throws Exception falls ein Parser/Lexer-Fehler auftritt.
	 */
	public Expression expr() throws Exception {
		return (Expression)this.parse().value;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see java_cup.runtime.lr_parser#report_error(java.lang.String, java.lang.Object)
	 */
	public void report_error(String message, Object info) {
		Symbol symbol = (Symbol)info;
		if (symbol.sym == EOF_sym()) {
			message = "Unerwartetes Dateiende";
		}
		throw new ParserException(message);
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see java_cup.runtime.lr_parser#report_fatal_error(java.lang.String, java.lang.Object)
	 */
	public void report_fatal_error(String message, Object info) throws Exception {
		report_error(message, info);
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see java_cup.runtime.lr_parser#syntax_error(java_cup.runtime.Symbol)
	 */
	public void syntax_error(Symbol cur_token) {
		report_error("Syntaxfehler bei Zeichen '" + cur_token.value + "'", cur_token);
	}
}
