package types;

import java.util.HashMap;

/**
 * Die Implementierung der Typumgebung gamma, die eine Funktion mit endlichem Definitionsbereich
 * darstellt, weswegen sie einfach als Map implementiert werden kann, die einer endlichen Menge
 * von Bezeichnern, die als <tt>String</tt>s realisiert sind, Typen zuordnet.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class TypeEnvironment {
	/**
	 * Die Zuordnung zwischen Bezeichnern und Typen.
	 */
	private HashMap map;
	
	/**
	 * Konstruktor fuer eine leere <tt>TypeEnvironment</tt>.
	 */
	public TypeEnvironment() {
		this.map = new HashMap();
	}
	
	/**
	 * Konstruktor fuer eine <tt>TypeEnvironment</tt>, die alle Zuordnungen
	 * von <tt>gamma</tt> erbt und zusaetzlich die Zuordnung von <tt>id</tt>
	 * nach <tt>tau</tt> enthaelt.
	 * 
	 * @param gamma die zu erbende Umgebung.
	 * @param id der Bezeichner fuer die neue Zuordnung.
	 * @param tau der Typ fuer die neue Zuordnung.
	 */
	public TypeEnvironment(TypeEnvironment gamma, String id, Type tau) {
		this.map = new HashMap(gamma.map);
		this.map.put(id, tau);
	}
	
	/**
	 * Sucht den Typ, der fuer <tt>id</tt> in der Typumgebung eingetragen worden ist.
	 * 
	 * @param id der Bezeichner dessen zugeordneter Typ gesucht wird.
	 * 
	 * @return den Typ fuer <tt>id</tt>.
	 * 
	 * @throws UnknownIdentifierException falls fuer <tt>id</tt> kein Typ in der
	 * 																		Typumgebung eingetragen worden ist.
	 */
	public Type lookup(String id) throws UnknownIdentifierException {
		Type tau = (Type)this.map.get(id);
		if (tau == null) {
			throw new UnknownIdentifierException(id);
		}
		return tau;
	}
}
