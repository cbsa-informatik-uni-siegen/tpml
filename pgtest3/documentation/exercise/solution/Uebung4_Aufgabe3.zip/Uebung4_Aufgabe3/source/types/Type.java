package types;

/**
 * Abstrakte Basisklasse fuer alle Typen, entspricht dem Nonterminal
 * tau in der abstrakten Syntaxdefinition.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public abstract class Type {
	/**
	 * {@inheritDoc}
	 *
	 * @see java.lang.Object#toString()
	 */
	public abstract String toString();
	
	/**
	 * {@inheritDoc}
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public abstract boolean equals(Object obj);
	
	/**
	 * {@inheritDoc}
	 *
	 * @see java.lang.Object#hashCode()
	 */
	public abstract int hashCode();
}
