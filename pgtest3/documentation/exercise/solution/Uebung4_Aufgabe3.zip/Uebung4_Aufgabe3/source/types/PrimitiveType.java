package types;

/**
 * Klasse fuer die primitiven Datentypen <b>unit</b>, <b>bool</b> und <b>int</b>. Es existiert
 * jeweils genau eine Instanz dieser Klasse fuer jeden der drei primitiven Datentypen, die als
 * oeffentliche Konstante zur Verfuegung steht.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class PrimitiveType extends Type {
	/**
	 * Die Instanz der Klasse <tt>PrimitiveType</tt> fuer <b>unit</b>-Typen.
	 */
	public static final PrimitiveType UNIT = new PrimitiveType("unit");
	
	/**
	 * Die Instanz der Klasse <tt>PrimitiveType</tt> fuer <b>bool</b>-Typen.
	 */
	public static final PrimitiveType BOOL = new PrimitiveType("bool");
	
	/**
	 * Die Instanz der Klasse <tt>PrimitiveType</tt> fuer <b>int</b>-Typen.
	 */
	public static final PrimitiveType INT = new PrimitiveType("int");
	
	/**
	 * Der Name des primitiven Datentyps, also entweder <tt>"unit"</tt>,
	 * <tt>"bool"</tt> oder <tt>"int"</tt>.
	 */
	private String name;
	
	/**
	 * Der Konstruktor fuer <tt>PrimitiveType</tt> ist privat, da nur die
	 * drei obigen Instanzen existieren duerfen.
	 * 
	 * @param name der Name des Datentyps.
	 */
	private PrimitiveType(String name) {
		this.name = name;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see types.Type#toString()
	 */
	public String toString() {
		return this.name;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see types.Type#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (obj instanceof PrimitiveType) {
			PrimitiveType other = (PrimitiveType)obj;
			return this.name.equals(other.name);
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see types.Type#hashCode()
	 */
	public int hashCode() {
		return this.name.hashCode();
	}
}
