package types;

/**
 * Ausnahmen, die signalisiert, dass kein Typ fuer einen bestimmten Bezeichner in einer
 * <tt>TypeEnvironment</tt> hinterlegt ist.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class UnknownIdentifierException extends Exception {
	/**
	 * Der Konstruktor fuer die <tt>UnknownIdentifierException</tt>.
	 * 
	 * @param id der Bezeichner, der nicht gefunden wurde in der Typumgebung.
	 */
	UnknownIdentifierException(String id) {
		super("Fuer den Bezeichner '" + id + "' konnte kein Typ gefunden werden");
	}
}
