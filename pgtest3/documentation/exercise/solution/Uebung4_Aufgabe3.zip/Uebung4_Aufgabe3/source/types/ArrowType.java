package types;

/**
 * Klasse fuer die Pfeildatentypen von Funktionen, also <tt>tau1 -&gt; tau2</tt>.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class ArrowType extends Type {
	/**
	 * Der Argumentdatentyp.
	 */
	private Type tau1;
	
	/**
	 * Der Ergebnisdatentyp.
	 */
	private Type tau2;
	
	/**
	 * Konstruktor fuer <tt>ArrowType</tt>s.
	 * 
	 * @param tau1 der Argumentdatentyp.
	 * @param tau2 der Ergebnisdatentyp.
	 */
	public ArrowType(Type tau1, Type tau2) {
		this.tau1 = tau1;
		this.tau2 = tau2;
	}
	
	/**
	 * Liefert den Argumentdatentyp.
	 * 
	 * @return den Argumentdatentyp.
	 */
	public Type getTau1() {
		return this.tau1;
	}
	
	/**
	 * Liefert den Ergebnisdatentyp.
	 * 
	 * @return den Ergebnisdatentyp.
	 */
	public Type getTau2() {
		return this.tau2;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see types.Type#toString()
	 */
	public String toString() {
		return "(" + this.tau1.toString() + " -> " + this.tau2.toString() + ")";
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see types.Type#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (obj instanceof ArrowType) {
			ArrowType other = (ArrowType)obj;
			return (this.tau1.equals(other.tau1) && this.tau2.equals(other.tau2));
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see types.Type#hashCode()
	 */
	public int hashCode() {
		return 1 + this.tau1.hashCode() + this.tau2.hashCode();
	}
}
