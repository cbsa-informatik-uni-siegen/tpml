package expressions;

import types.Type;
import types.TypeEnvironment;
import types.UnknownIdentifierException;

/**
 * Klasse fuer Let-Ausdruecke, also let id = e1 in e2 in der abstrakten Syntaxdefinition.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Let extends Expression {
	/**
	 * Der Bezeichners fuer die Bindung.
	 */
	private String id;
	
	/**
	 * Der erste Teilausdruck.
	 */
	private Expression e1;
	
	/**
	 * Der zweite Teilausdruck.
	 */
	private Expression e2;
	
	/**
	 * Konstruktor fuer neue <tt>Let</tt>s.
	 * 
	 * @param id der Bezeichner fuer die Bindung.
	 * @param e1 der erste Teilausdruck.
	 * @param e2 der zweite Teilausdruck.
	 */
	public Let(String id, Expression e1, Expression e2) {
		this.id = id;
		this.e1 = e1;
		this.e2 = e2;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see expressions.Expression#typeof(types.TypeEnvironment)
	 */
	public Type typeof(TypeEnvironment gamma) throws IlltypedException,	UnknownIdentifierException {
		// zunaechst den Typ von e1 bestimmen...
		Type tau1 = this.e1.typeof(gamma);
		
		// dann in der um tau1/id erweiterten Typumgebung den von e2...
		Type tau2 = this.e2.typeof(new TypeEnvironment(gamma, this.id, tau1));
		
		// und das ist dann der Typ des Gesamtausdrucks
		return tau2;
	}
}
