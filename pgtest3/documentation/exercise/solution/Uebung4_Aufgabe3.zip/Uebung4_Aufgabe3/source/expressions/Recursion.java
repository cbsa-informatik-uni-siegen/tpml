package expressions;

import types.Type;
import types.TypeEnvironment;
import types.UnknownIdentifierException;

/**
 * Klasse fuer rekursive Ausdruecke, also rec id:tau.e in der abstrakten Syntaxdefinition.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Recursion extends Expression {
	/**
	 * Der Bezeichner fuer die Bindung.
	 */
	private String id;
	
	/**
	 * Der Typ fuer den Bezeichner.
	 */
	private Type tau;
	
	/**
	 * Der Rekursionskoerper.
	 */
	private Expression e;
	
	/**
	 * Konstruktor fuer rekursive Ausdruecke, mit <tt>tau</tt> fuer <tt>id</tt> in <tt>e</tt>.
	 * 
	 * @param id der Bezeichner fuer die Bindung.
	 * @param tau der Typ fuer den Bezeichner <tt>id</tt>.
	 * @param e der Koerper der Rekursion.
	 */
	public Recursion(String id, Type tau, Expression e) {
		this.id = id;
		this.tau = tau;
		this.e = e;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see expressions.Expression#typeof(types.TypeEnvironment)
	 */
	public Type typeof(TypeEnvironment gamma) throws IlltypedException,	UnknownIdentifierException {
		// den Typ von e in der um tau/id erweiterten Typumgebung bestimmen...
		Type tau$ = this.e.typeof(new TypeEnvironment(gamma, this.id, this.tau));
		
		// dann muessen tau und tau$ uebereinstimmen
		if (!tau$.equals(this.tau)) {
			throw new IlltypedException("Der fuer die Rekursion angegebene Typ " + this.tau.toString()
																	+ " stimmt nicht mit dem tatsaechlichen Typ " + tau$.toString()
																	+ " ueberein");
		}
		
		// Typ des Ausdrucks ist klar
		return this.tau;
	}
}
