package expressions;

import types.Type;
import types.TypeEnvironment;
import types.UnknownIdentifierException;

/**
 * Abstrakte Basisklasse fuer Ausdruecke, entspricht also dem e
 * in der abstrakten Syntaxdefinition.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public abstract class Expression {
	/**
	 * Liefert den <tt>Type</tt> fuer diesen Ausdruck in der Typumgebung <tt>gamma</tt>.
	 * 
	 * @param gamma die <tt>TypeEnvironment</tt> in der der Typ bestimmt werden soll.
	 * 
	 * @return den Typ fuer diesen Ausdruck.
	 * 
	 * @throws IlltypedException falls der Ausdruck nicht wohlgetypt ist.
	 * @throws UnknownIdentifierException falls bei der Bestimmung des Typs ein ungebundener
	 * 																		Bezeichner aufgetreten ist.
	 */
	public abstract Type typeof(TypeEnvironment gamma) throws IlltypedException, UnknownIdentifierException;
}
