package expressions;

import types.Type;
import types.TypeEnvironment;
import types.UnknownIdentifierException;

/**
 * Klasse fuer Bezeichner, entspricht also id in der abstrakten Syntaxdefinition.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Identifier extends Expression {
	/**
	 * Der Name des Bezeichners.
	 */
	private String name;
	
	/**
	 * Konstruktor fuer einen <tt>Identifier</tt> mit dem Namen <tt>name</tt>.
	 * 
	 * @param name der Name des zu erstellenden Identifiers.
	 */
	public Identifier(String name) {
		this.name = name;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see expressions.Expression#typeof(types.TypeEnvironment)
	 */
	public Type typeof(TypeEnvironment gamma) throws IlltypedException, UnknownIdentifierException {
		return gamma.lookup(this.name);
	}
}
