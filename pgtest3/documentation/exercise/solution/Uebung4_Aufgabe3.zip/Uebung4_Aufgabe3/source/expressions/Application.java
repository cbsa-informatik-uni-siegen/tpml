package expressions;

import types.ArrowType;
import types.Type;
import types.TypeEnvironment;
import types.UnknownIdentifierException;

/**
 * Klasse fuer Applikationen, also e1 e2 in der abstrakten Syntaxdefinition.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Application extends Expression {
	/**
	 * Der erste Teilausdruck.
	 */
	private Expression e1;
	
	/**
	 * Der zweite Teilausdruck.
	 */
	private Expression e2;
	
	/**
	 * Konstruktor fuer eine <tt>Application</tt> von <tt>e1</tt> auf <tt>e2</tt>.
	 * 
	 * @param e1 der erste Teilausdruck.
	 * @param e2 der zweite Teilausdruck.
	 */
	public Application(Expression e1, Expression e2) {
		this.e1 = e1;
		this.e2 = e2;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see expressions.Expression#typeof(types.TypeEnvironment)
	 */
	public Type typeof(TypeEnvironment gamma) throws IlltypedException, UnknownIdentifierException {
		// zunaechst die Typen von e1 und e2 bestimmen
		Type tau1 = this.e1.typeof(gamma);
		Type tau2 = this.e2.typeof(gamma);
		
		// tau1 muss nun ein Pfeiltyp sein...
		if (tau1 instanceof ArrowType) {
			// und der Argumenttyp von tau1 muss tau2 sein...
			ArrowType tau1a = (ArrowType)tau1;
			if (tau1a.getTau1().equals(tau2)) {
				// dann ist der Ergebnistyp von tau1 unser gesuchter Typ
				return tau1a.getTau2();
			}
			else {
				throw new IlltypedException("Der Argumenttyp von " + tau1.toString() + " und "
																		+ tau2.toString() + " stimmen nicht ueberein");
			}
		}
		else {
			throw new IlltypedException(tau1.toString() + " ist kein Pfeiltyp");
		}
	}
}
