package expressions;

import types.PrimitiveType;
import types.Type;
import types.TypeEnvironment;
import types.UnknownIdentifierException;

/**
 * Klasse fuer bedingte Ausdruecke, also if e0 then e1 else e2 in der abstrakten Syntaxdefinition.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Condition extends Expression {
	/**
	 * Der Teilausdruck fuer die Bedingung.
	 */
	private Expression e0;
	
	/**
	 * Der Teilausdruck fuer den true-Block.
	 */
	private Expression e1;
	
	/**
	 * Der Teilausdruck fuer den false-Block.
	 */
	private Expression e2;
	
	/**
	 * Konstruktor fuer <tt>Condition</tt>s mit <tt>e0</tt>, <tt>e1</tt> und <tt>e2</tt>.
	 * 
	 * @param e0 der Teilausdruck fuer die Bedingung.
	 * @param e1 der Teilausdruck fuer den true-Block.
	 * @param e2 der Teilausdruck fuer den false-Block.
	 */
	public Condition(Expression e0, Expression e1, Expression e2) {
		this.e0 = e0;
		this.e1 = e1;
		this.e2 = e2;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see expressions.Expression#typeof(types.TypeEnvironment)
	 */
	public Type typeof(TypeEnvironment gamma) throws IlltypedException,	UnknownIdentifierException {
		// der Typ von e0 muss bool sein...
		Type tau0 = this.e0.typeof(gamma);
		if (!tau0.equals(PrimitiveType.BOOL)) {
			throw new IlltypedException("Die Bedingung sollte vom Typ bool sein, ist aber " + tau0.toString());
		}
		
		// und die Typen von e1 und e2 muessen uebereinstimmen
		Type tau1 = this.e1.typeof(gamma);
		Type tau2 = this.e2.typeof(gamma);
		if (!tau1.equals(tau2)) {
			throw new IlltypedException("Der Typ " + tau1 + " des true-Blocks stimmt nicht mit dem Typ "
																	+ tau2 + " des false-Blocks ueberein");
		}
		
		// der Typ des Ausdrucks ist dann tau1 bzw. tau2
		return tau1;
	}
}
