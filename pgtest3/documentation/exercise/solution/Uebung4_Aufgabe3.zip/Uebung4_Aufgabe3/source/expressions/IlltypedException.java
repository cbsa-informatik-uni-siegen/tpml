package expressions;

/**
 * Diese Ausnahmen wird von {@link expressions.Expression#typeof(TypeEnvironment)} generiert, wenn
 * der Ausdruck nicht wohlgetypt ist.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class IlltypedException extends Exception {
	/**
	 * Konstruktor fuer <tt>IlltypedException</tt> mit der entsprechenden <tt>message</tt>.
	 * 
	 * @param message die Fehlermeldung.
	 */
	IlltypedException(String message) {
		super(message);
	}
}
