package expressions;

import types.ArrowType;
import types.Type;
import types.TypeEnvironment;
import types.UnknownIdentifierException;

/**
 * Klasse fuer Lambda-Abstraktionen, also lambda id:tau.e in der abstrakten Syntaxdefinition.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Abstraction extends Expression {
	/**
	 * Der Bezeichner fuer die Bindung.
	 */
	private String id;
	
	/**
	 * Der Typ fuer den Bezeichner.
	 */
	private Type tau;
	
	/**
	 * Der Funktionskoerper.
	 */
	private Expression e;
	
	/**
	 * Der Konstruktor fuer <tt>Abstraction</tt>s, mit <tt>tau</tt> fuer <tt>id</tt> in <tt>e</tt>.
	 * 
	 * @param id der Bezeichner fuer die Bindung.
	 * @param tau der Typ fuer den Bezeichner <tt>id</tt>.
	 * @param e der Koerper der Funktion.
	 */
	public Abstraction(String id, Type tau, Expression e) {
		this.id = id;
		this.tau = tau;
		this.e = e;
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see expressions.Expression#typeof(types.TypeEnvironment)
	 */
	public Type typeof(TypeEnvironment gamma) throws IlltypedException,	UnknownIdentifierException {
		// zunaechst in der erweiterten Typumgebung den Typ von e bestimmen...
		Type tau$ = this.e.typeof(new TypeEnvironment(gamma, this.id, this.tau));
		
		// kombiniert mit tau gibt das dann tau -> tau$
		return new ArrowType(this.tau, tau$);
	}
}
