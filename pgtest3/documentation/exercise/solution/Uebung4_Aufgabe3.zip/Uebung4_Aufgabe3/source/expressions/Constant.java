package expressions;

import types.ArrowType;
import types.PrimitiveType;
import types.Type;
import types.TypeEnvironment;
import types.UnknownIdentifierException;

/**
 * Klasse fuer konstante Ausdruecke, also das c in der abstrakten Syntaxdefinition. Die
 * konkreten Werte von Konstanten, also ob eine Ganzzahl nun den Wert 7 oder 42 hat, sind
 * irrelevant fuer die Typueberpruefung. Es ist lediglich wichtig, welchen Typ die Konstante
 * hat.
 * 
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Constant extends Expression {
	/**
	 * Die Unit-Konstant, also ().
	 */
	public static final Constant UNIT = new Constant();
	
	/**
	 * Die Bool-Konstanten true und false.
	 */
	public static final Constant BOOL = new Constant();
	
	/**
	 * Die Ganzzahl-Konstanten.
	 */
	public static final Constant INT = new Constant();
	
	/**
	 * Die arithmetischen Operatoren.
	 */
	public static final Constant AOP = new Constant();
	
	/**
	 * Die relationalen Operatoren.
	 */
	public static final Constant ROP = new Constant();
	
	/**
	 * Der Konstruktor fuer <tt>Constant</tt>s.
	 * 
	 * Der Konstruktor ist
	 * private, da nur die fuenf obigen Instanzen existieren; eine Vereinfachung, die gueltig
	 * ist, da fuer die Typueberpruefung irrelevant ist, ob es sich bei einer Ganzzahl nun um
	 * eine 7 oder eine 42 handelt, es interessiert lediglich, dass wir eine Ganzzahl haben.
	 * 
	 * Fuer einen Interpreter basierend auf dieser Darstellung der abstrakten Syntax, ist es
	 * natuerlich unbedingt notwendig, die konkreten Werte zu wissen.
	 */
	private Constant() {
		
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * @see expressions.Expression#typeof(types.TypeEnvironment)
	 */
	public Type typeof(TypeEnvironment gamma) throws IlltypedException,	UnknownIdentifierException {
		// hier koennen wir direkt die fuenf einzigen Instanzen dieser Klasse pruefen, ueber die
		// Referenzen, da sie sich lediglich durch ihre Identitaet unterscheiden
		if (this == UNIT) {
			return PrimitiveType.UNIT;
		}
		else if (this == BOOL) {
			return PrimitiveType.BOOL;
		}
		else if (this == INT) {
			return PrimitiveType.INT;
		}
		else if (this == AOP) {
			return new ArrowType(PrimitiveType.INT, new ArrowType(PrimitiveType.INT, PrimitiveType.INT));
		}
		else {
			return new ArrowType(PrimitiveType.INT, new ArrowType(PrimitiveType.INT, PrimitiveType.BOOL));
		}
	}
}
