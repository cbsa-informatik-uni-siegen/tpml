import java.io.StringReader;

import parser.Parser;
import types.TypeEnvironment;
import expressions.Expression;

/**
 * Startklasse fuer den Type Checker.
 *
 * @author Benedikt Meurer (meurer@informatik.uni-siegen.de)
 * @version $Rev: 39 $
 */
public final class Main {
	/**
	 * Der Ausdruck, fuer den der Typ bestimmt werden soll, in konkreter Syntax.
	 * 
	 * Zur Uebung auch ruhig mal falsche Sachen eingeben. Als Pruefungsvorbereitung eignet
	 * sich die Erweiterung des Programms auf syntaktischen Zucker, z.B. (LET-REC) und
	 * (LET-CURRY), sowie das schreiben eines BigStep/SmallStep-Interpreters basierend
	 * auf dieser abstrakten Syntax (Hinweis: F�r syntaktischen Zucker muss auch der
	 * Parser erweitert werden, siehe dazu die parser.cup und das build.xml Skript).
	 */
	private static final String EXPR =
		"let f = rec f:int->int.lambda x:int.if x = 0 then 1 else x * f (x - 1) in f 3";
	
	/**
	 * Programmeinstiegspunkt.
	 * 
	 * @param args Kommandozeilenparameter.
	 */
	public static void main(String[] args) {
		try {
			// 1. Schritt: Parsen
			Parser parser = new Parser(new StringReader(EXPR));
			Expression e = parser.expr();
			
			// 2. Schritt: Typueberpruefung
			System.out.println(e.typeof(new TypeEnvironment()).toString());
			
			// 3. Schritt: Interpretation/Codeerzeugung (bleibt als Uebung)
		}
		catch (Exception e) {
			System.out.println("FEHLER: " + e.getMessage());
		}
	}
}
